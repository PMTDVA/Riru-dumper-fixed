#ifndef PLATFORM_INTERFACE_CLEAR_CACHE_TOOL_H
#define PLATFORM_INTERFACE_CLEAR_CACHE_TOOL_H

void ClearCache(void *start, void *end);

#endif