
#ifndef CONSTANTS_HEADER_H
#define CONSTANTS_HEADER_H

#define RT_FAILED  -1
#define RT_SUCCESS 0

#endif