# Intro

a lightweight, multi-platform, multi-architecture exploit hook framework.

**tips: any question [go to Discord](https://discordapp.com/invite/dAEEywt)**

- Minimal and modular library
- Multi-platform support(Windows/macOS/iOS/Android/Linux)
- Multiple architecture support(X86-64, ARM, ARM64)
- Clean code without STL(port to kernel easily)
- Plugin support(DobbyDrill ?)
- iOS kernel exploit support(Gollum ?)

**[CHANGELOG]()**
