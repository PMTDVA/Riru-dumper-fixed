# Dobby <small>beta</small>

> An exploit hook framework

[GitHub](https://github.com/jmpews/dobby)
[Get Started](#intro)
